package com.tyrique.imad5112part1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        calculator()
    }

   fun calculator()
   {
       val num1 = findViewById<EditText>(R.id.number1)
       val num2 = findViewById<EditText>(R.id.number2)
       val button = findViewById<Button>(R.id.add)
       val clearbutton = findViewById<Button>(R.id.clearbutton)
       val subtract = findViewById<Button>(R.id.subtract)
       val multiply = findViewById<Button>(R.id.multiply)
       val divide = findViewById<Button>(R.id.divide)

       button.setOnClickListener{
          val addnum1 = num1.text.toString().toInt()
           val addnum2 = num2.text.toString().toInt()
           val result = addnum1 + addnum2

           Toast.makeText(this,"$result",Toast.LENGTH_SHORT).show()
       }
       subtract.setOnClickListener{
           val addnum1 = num1.text.toString().toInt()
           val addnum2 = num2.text.toString().toInt()
           val result = addnum1 - addnum2

           Toast.makeText(this,"$result",Toast.LENGTH_SHORT).show()
       }
       multiply.setOnClickListener{
           val addnum1 = num1.text.toString().toInt()
           val addnum2 = num2.text.toString().toInt()
           val result = addnum1 * addnum2

           Toast.makeText(this,"$result",Toast.LENGTH_SHORT).show()
       }
       divide.setOnClickListener{
           val addnum1 = num1.text.toString().toInt()
           val addnum2 = num2.text.toString().toInt()
           val result = addnum1 / addnum2

           Toast.makeText(this,"$result",Toast.LENGTH_SHORT).show()
       }
       clearbutton.setOnClickListener {
           num1.setText("")
           num2.setText("")

           fun main() {
               while (true) {
                   println("Enter two numbers (or 'exit' to quit):")
                   val input1 = readLine()
                   if (input1 == "exit") break
                   val num1 = input1!!.toDouble()
                   val num2 = readLine()!!.toDouble()

                   println("Enter an operator (+, -, *, /, sqrt, ^):")
                   when (val operator = readLine()) {
                       "sqrt" -> {
                           if (num1 < 0) {
                               println("sqrt($num1) = ${sqrt(abs(num1))}i")
                           } else {
                               println("sqrt($num1) = ${sqrt(num1)}")
                           }
                       }
                       "^" -> {
                           var result = num1
                           for (i in 1 until num2.toInt()) {
                               result *= num1
                           }
                           println("$num1^$num2 = $result")
                       }
                       "/" -> {
                           if (num2 == 0.0) {
                               println("Error! Division by zero is not allowed.")
                           } else {
                               println("$num1 / $num2 = ${num1 / num2}")
                           }
                       }
                       "+" -> println("$num1 + $num2 = ${num1 + num2}")
                       "-" -> println("$num1 - $num2 = ${num1 - num2}")
                       "*" -> println("$num1 * $num2 = ${num1 * num2}")
                       else -> println("$operator is not a valid operator.")
                   }
               }
           }



           Toast.makeText(this,"Cleared",Toast.LENGTH_SHORT).show()

       }










   }

}




